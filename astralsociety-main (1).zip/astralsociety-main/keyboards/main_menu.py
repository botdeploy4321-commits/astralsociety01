from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import SUPPORT_GROUP_LINK, SUPPORT_CHANNEL_LINK, BOT_ADD_LINK, WEBSITE_URL


# ═══════════════════════════════════════════════
# MAIN MENU
# ═══════════════════════════════════════════════
def main_menu_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🆘 ʜᴇʟᴘ", callback_data="menu:help"),
         InlineKeyboardButton(text="ℹ️ ᴀʙᴏᴜᴛ", callback_data="menu:about")],
        [InlineKeyboardButton(text="👥 ꜱᴜᴘᴘᴏʀᴛɪᴠᴇ ɢᴄ", url=SUPPORT_GROUP_LINK)],
        [InlineKeyboardButton(text="📢 ꜱᴜᴘᴘᴏʀᴛɪᴠᴇ ᴄʜᴀɴɴᴇʟ", url=SUPPORT_CHANNEL_LINK)],
        [InlineKeyboardButton(text="🌐 ᴡᴇʙꜱɪᴛᴇ", url=WEBSITE_URL)],
        [InlineKeyboardButton(text="🎯 ᴄʟᴏɴᴇ ʙᴏᴛ", callback_data="clone:start")],
        [InlineKeyboardButton(text="🥷 ᴋɪᴅɴᴀᴘ ᴍᴇ", url=BOT_ADD_LINK)],
    ])


def back_kb(target="menu:main"):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="↩️ ʙᴀᴄᴋ", callback_data=target)]
    ])


def back_main_kb():
    return back_kb("menu:main")


# ═══════════════════════════════════════════════
# 🎮 GAMES MENU
# ═══════════════════════════════════════════════
def tgames_menu_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🧠 ǫᴜɪᴢ", callback_data="tg:quiz")],
        [InlineKeyboardButton(text="🔢 ɢᴜᴇꜱꜱ ᴛʜᴇ ɴᴜᴍʙᴇʀ", callback_data="tg:number")],
        [InlineKeyboardButton(text="↩️ ʙᴀᴄᴋ", callback_data="menu:main")],
    ])


# ═══════════════════════════════════════════════
# 🧠 QUIZ
# ═══════════════════════════════════════════════
def quiz_count_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="5 ǫᴜᴇꜱᴛɪᴏɴꜱ", callback_data="qzcount:5"),
         InlineKeyboardButton(text="10 ǫᴜᴇꜱᴛɪᴏɴꜱ", callback_data="qzcount:10")],
        [InlineKeyboardButton(text="15 ǫᴜᴇꜱᴛɪᴏɴꜱ", callback_data="qzcount:15"),
         InlineKeyboardButton(text="20 ǫᴜᴇꜱᴛɪᴏɴꜱ", callback_data="qzcount:20")],
        [InlineKeyboardButton(text="↩️ ʙᴀᴄᴋ", callback_data="menu:games")],
    ])


def quiz_menu_kb():
    categories = [
        ("🚀 ꜱᴘᴀᴄᴇ", "quiz:space"),
        ("🌍 ɢᴇɴᴇʀᴀʟ", "quiz:general"),
        ("🔬 ꜱᴄɪᴇɴᴄᴇ", "quiz:science"),
        ("📜 ʜɪꜱᴛᴏʀʏ", "quiz:history"),
        ("🗺️ ɢᴇᴏɢʀᴀᴘʜʏ", "quiz:geography"),
        ("🔢 ᴍᴀᴛʜꜱ", "quiz:maths"),
        ("💻 ᴛᴇᴄʜ", "quiz:tech"),
        ("⚽ ꜱᴘᴏʀᴛꜱ", "quiz:sports"),
        ("🎬 ᴍᴏᴠɪᴇꜱ", "quiz:movies"),
        ("🎵 ᴍᴜꜱɪᴄ", "quiz:music"),
        ("🐾 ᴀɴɪᴍᴀʟꜱ", "quiz:animals"),
        ("🍔 ꜰᴏᴏᴅ", "quiz:food"),
        ("📖 ʟɪᴛᴇʀᴀᴛᴜʀᴇ", "quiz:literature"),
        ("🏛️ ᴘᴏʟɪᴛɪᴄꜱ", "quiz:politics"),
        ("💰 ʙᴜꜱɪɴᴇꜱꜱ", "quiz:business"),
    ]
    rows = []
    for i in range(0, len(categories), 2):
        row = [InlineKeyboardButton(text=categories[i][0], callback_data=categories[i][1])]
        if i + 1 < len(categories):
            row.append(InlineKeyboardButton(text=categories[i + 1][0], callback_data=categories[i + 1][1]))
        rows.append(row)
    rows.append([InlineKeyboardButton(text="↩️ ʙᴀᴄᴋ", callback_data="tg:quiz")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def quiz_options_kb(qid, a, b, c, d):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"ᴀ) {a[:40]}", callback_data=f"qans:{qid}:A")],
        [InlineKeyboardButton(text=f"ʙ) {b[:40]}", callback_data=f"qans:{qid}:B")],
        [InlineKeyboardButton(text=f"ᴄ) {c[:40]}", callback_data=f"qans:{qid}:C")],
        [InlineKeyboardButton(text=f"ᴅ) {d[:40]}", callback_data=f"qans:{qid}:D")],
    ])


# ═══════════════════════════════════════════════
# 🏆 LEADERBOARD — 4 TABS
# ═══════════════════════════════════════════════
def leaderboard_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📅 ᴛᴏᴅᴀʏ", callback_data="lb:today"),
            InlineKeyboardButton(text="📆 ᴡᴇᴇᴋʟʏ", callback_data="lb:weekly"),
        ],
        [
            InlineKeyboardButton(text="🗓️ ᴍᴏɴᴛʜʟʏ", callback_data="lb:monthly"),
            InlineKeyboardButton(text="🌐 ᴀʟʟ-ᴛɪᴍᴇ", callback_data="lb:alltime"),
        ],
        [
            InlineKeyboardButton(text="↩️ ʙᴀᴄᴋ", callback_data="menu:main"),
        ],
    ])


# ═══════════════════════════════════════════════
# 📚 STUDY
# ═══════════════════════════════════════════════
def study_class_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📘 ᴄʟᴀꜱꜱ 10", callback_data="study:10"),
         InlineKeyboardButton(text="📗 ᴄʟᴀꜱꜱ 11", callback_data="study:11")],
        [InlineKeyboardButton(text="📕 ᴄʟᴀꜱꜱ 12", callback_data="study:12")],
        [InlineKeyboardButton(text="↩️ ʙᴀᴄᴋ", callback_data="menu:main")],
    ])


def study_class10_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔬 ꜱᴄɪᴇɴᴄᴇ", callback_data="st10:subject:science"),
         InlineKeyboardButton(text="📐 ᴍᴀᴛʜꜱ", callback_data="st10:subject:maths")],
        [InlineKeyboardButton(text="🌍 ꜱꜱᴛ", callback_data="st10:subject:sst"),
         InlineKeyboardButton(text="📖 ᴇɴɢʟɪꜱʜ", callback_data="st10:subject:english")],
        [InlineKeyboardButton(text="📝 ᴘʏǫ", callback_data="st10:section:pyq")],
        [InlineKeyboardButton(text="↩️ ʙᴀᴄᴋ", callback_data="menu:study")],
    ])


def study_class1112_kb(class_name):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎯 ᴊᴇᴇ", callback_data=f"st{class_name}:section:jee")],
        [InlineKeyboardButton(text="🩺 ɴᴇᴇᴛ", callback_data=f"st{class_name}:section:neet")],
        [InlineKeyboardButton(text="🎯🩺 ᴊᴇᴇ + ɴᴇᴇᴛ", callback_data=f"st{class_name}:section:both")],
        [InlineKeyboardButton(text="📝 ᴘʏǫꜱ", callback_data=f"st{class_name}:section:pyq")],
        [InlineKeyboardButton(text="↩️ ʙᴀᴄᴋ", callback_data="menu:study")],
    ])


def chapters_kb(class_name, section, chapters):
    rows = []
    for i, ch in enumerate(chapters):
        rows.append([InlineKeyboardButton(
            text=f"📄 {ch}",
            callback_data=f"stch:{class_name}:{section}:{i}"
        )])
    rows.append([InlineKeyboardButton(text="↩️ ʙᴀᴄᴋ", callback_data=f"study:{class_name}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ═══════════════════════════════════════════════
# 🛒 SHOP — MAIN MENU
# ═══════════════════════════════════════════════
def shop_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛡️ ᴘʀᴏᴛᴇᴄᴛɪᴏɴ ᴄʜᴇᴄᴋᴇʀ", callback_data="shop:protection")],
        [InlineKeyboardButton(text="⚡ xᴘ ʙᴏᴏꜱᴛ", callback_data="shop:xpboost")],
        [InlineKeyboardButton(text="🎟️ ᴇxᴛʀᴀ ᴘʟᴀʏ (15 💎)", callback_data="shop:extraplay")],
        [InlineKeyboardButton(text="🔮 ᴍʏꜱᴛᴇʀʏ ᴄʜᴇꜱᴛ (30 💎)", callback_data="shop:mystery")],
        [InlineKeyboardButton(text="↩️ ʙᴀᴄᴋ", callback_data="menu:main")],
    ])


# ═══════════════════════════════════════════════
# 🛡️ PROTECTION CHECKER PLANS
# ═══════════════════════════════════════════════
def protection_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛡️ ʙᴀꜱɪᴄ — 7 ᴅᴀʏꜱ (30 💎)", callback_data="shop:pc:basic")],
        [InlineKeyboardButton(text="🛡️ ᴀᴅᴠᴀɴᴄᴇᴅ — 21 ᴅᴀʏꜱ (80 💎)", callback_data="shop:pc:advanced")],
        [InlineKeyboardButton(text="🛡️ ᴜʟᴛɪᴍᴀᴛᴇ — 60 ᴅᴀʏꜱ (150 💎)", callback_data="shop:pc:ultimate")],
        [InlineKeyboardButton(text="↩️ ʙᴀᴄᴋ", callback_data="shop:back")],
    ])


# ═══════════════════════════════════════════════
# ⚡ XP BOOST PLANS
# ═══════════════════════════════════════════════
def xpboost_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⚡ ʙᴀꜱɪᴄ — 7 ᴅᴀʏꜱ (30 💎)", callback_data="shop:xp:basic")],
        [InlineKeyboardButton(text="⚡ ᴀᴅᴠᴀɴᴄᴇᴅ — 21 ᴅᴀʏꜱ (80 💎)", callback_data="shop:xp:advanced")],
        [InlineKeyboardButton(text="⚡ ᴜʟᴛɪᴍᴀᴛᴇ — 60 ᴅᴀʏꜱ (150 💎)", callback_data="shop:xp:ultimate")],
        [InlineKeyboardButton(text="↩️ ʙᴀᴄᴋ", callback_data="shop:back")],
    ])


# ═══════════════════════════════════════════════
# ⭐ PREMIUM
# ═══════════════════════════════════════════════
def premium_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="1 ᴡᴇᴇᴋ — 1,000 💎", callback_data="prem_buy:1w")],
        [InlineKeyboardButton(text="1 ᴍᴏɴᴛʜ — 10,000 💎", callback_data="prem_buy:1m")],
        [InlineKeyboardButton(text="1 ʏᴇᴀʀ — 100,000 💎", callback_data="prem_buy:1y")],
        [InlineKeyboardButton(text="↩️ ʙᴀᴄᴋ", callback_data="menu:main")],
    ])
